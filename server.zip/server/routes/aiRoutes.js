const express = require("express");

const router = express.Router();

const auth = require("../middleware/auth");

const aiLimiter = require("../middleware/aiLimiter");

const {
  getRecommendation
} = require("../controllers/aiController");


router.post(
  "/recommendation",
  auth,
  aiLimiter,
  getRecommendation
);


module.exports = router;